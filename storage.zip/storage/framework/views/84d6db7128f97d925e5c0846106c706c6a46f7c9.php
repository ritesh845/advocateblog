<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="card-title">Edit Post
         <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-sm btn-primary pull-right">Back</a>
         </h5>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('posts.update',$post->article_id)); ?>" method="post" enctype="multipart/form-data" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <?php if (app('laratrust')->hasRole('admin|super_admin')) : ?>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label>Select User</label>
                        <select name="user_id" class="form-control" required="required">
                            <option value="">Select User</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e($post->user_id == $user->id ? 'selected="selected"' : ''); ?>><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>            
            <?php endif; // app('laratrust')->hasRole ?>

            <?php if (app('laratrust')->hasRole('user')) : ?>
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
            <?php endif; // app('laratrust')->hasRole ?>

            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" class="form-control" placeholder="Post Title" value="<?php echo e(old('title') ?? $post->title); ?>" id="title">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 form-group">
                    <label for="sefriendly">Sefriendly Url</label>
                    <input type="text" name="sefriendly" value="<?php echo e(old('sefriendly') ?? $post->sefriendly); ?>" class="form-control" readonly="readonly" id="sefriendly" placeholder="Sefriendly Url">
                    <?php $__errorArgs = ['sefriendly'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="start_date">Start Date</label>
                    <input type="text" name="start_date" class="form-control datepicker" placeholder="yyyy-mm-dd" data-date-format='yyyy-mm-dd' value="<?php echo e(old('start_date') ?? date('Y-m-d',strtotime($post->start_date))); ?>" id="start_date">
                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                
            </div>
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="image">Image</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 form-group">
                    <label for="attachment">Attachment <span class="text-muted">(PDF Accepted)</span></label>
                    <input type="file" name="attachment" class="form-control" accept="application/pdf">
                    <?php $__errorArgs = ['attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>     
            <hr>                   
           
          
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="status">Status</label>
                    <select class="form-control" name="status">
                        <option value="1" <?php echo e($post->status == '1' ? 'selected="selected"' : ''); ?>>Active</option>
                        <option value="0" <?php echo e($post->status == '0' ? 'selected="selected"' : ''); ?>>Not Active</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="status">Meta title</label>
                    <input type="text" name="meta_title" class="form-control" placeholder="Post meta title" value="<?php echo e(old('meta_title') ?? $post->meta_title); ?>" id="meta_title">
                    <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 form-group">
                    <label for="status">Meta description</label>
                    
                     <input type="text" name="meta_description" class="form-control" placeholder="Post Meta Description" value="<?php echo e(old('meta_description') ?? $post->meta_description); ?>" id="meta_description">
                    <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 form-group">
                    <label for="status">Meta Keywords</label>
                   
                    <input type="text" name="meta_keywords" class="form-control" placeholder="Post meta keywords" value="<?php echo e(old('meta_keywords') ?? $post->meta_keywords); ?>" id="meta_keywords">
                    <?php $__errorArgs = ['meta_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>



            <div class="row">
                <div class="col-md-12 form-group">
                    <label for="body">Body</label>
                    <textarea class="form-control" name="body" rows="10" cols="20" placeholder="Enter Body Content" id="editor"><?php echo e(old('body') ?? $post->body); ?></textarea>
                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 form-group">
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
<script >
    $(document).ready(function(){
        CKEDITOR.replace('editor');
        $('.datepicker').datepicker({
            'setDate': new Date()
        });


        $('#title').blur(function(e){
            var text = document.getElementById("title").value;
            str = text.replace(/[`~!@#$%^&*()_\-+=\[\]{};:'"\\|\/,.<>?\s]/g, ' ').toLowerCase();
            str = str.replace(/^\s+|\s+$/gm,'');
            str = str.replace(/\s+/g, '-');   
            $("#sefriendly").val(str); 
        });

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/posts/edit.blade.php ENDPATH**/ ?>