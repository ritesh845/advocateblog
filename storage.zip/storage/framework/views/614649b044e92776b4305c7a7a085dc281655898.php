<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-sm-12">
      <form action="<?php echo e(route('domain.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-sm-6">
               <div class="form-group">
                  <label for="domain_name">Domain Name</label>
                  <input type="text" name="domain_name" class="form-control" id="domain_name"  placeholder="Enter domain_name">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="domain_url">Domain Url</label>
                  <input type="text" name="domain_url" class="form-control" id="domain_url" placeholder="Enter domain_url">
                </div> 
            </div>
          </div>

          <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label for="domain_email">Domain Email</label>
                <input type="text" name="domain_email" class="form-control" id="domain_email" placeholder="Enter domain_email">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label for="person_name">Person Name</label>
                <input type="text" name="person_name" class="form-control" id="person_name " placeholder="Enter person_name ">
              </div>
            </div>
          </div>
           <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="domain_logo">Domain Logo</label>
                    <input type="file" name="domain_logo" class="form-control" id="domain_logo" placeholder="Enter domain_logo">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                    <label for="no_of_post">No of Post</label>
                    <input type="text" name="no_of_post" class="form-control" id="no_of_post" placeholder="Enter no_of_post">
                </div>
              </div>
          </div>
           <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="sitename">Site Name</label>
                    <input type="text" name="sitename" class="form-control" id=" sitename" placeholder="Enter sitename">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                    <label for="site_logo">Site Logo</label>
                    <input type="file" name="site_logo" class="form-control" id="site_logo" placeholder="Enter site_logo">
                </div>
              </div>
          </div>
          <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="address">Address</label>
                    
                    <textarea name="address" class="form-control" id="address" placeholder="Enter your address"></textarea>
                </div>
              </div>
          </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/domain/create.blade.php ENDPATH**/ ?>