<?php echo $__env->make('backend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <div class="main-content">

<!-- responsive header -->
<div class="panel-body">
    <?php echo $__env->yieldContent('content'); ?>
    <div class="bottombar"> 
        <span>© 2019. All Rights Reserved.</span>
    </div>
    <!-- bottombar -->
</div>
</div>
<?php echo $__env->make('backend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/layouts/main.blade.php ENDPATH**/ ?>