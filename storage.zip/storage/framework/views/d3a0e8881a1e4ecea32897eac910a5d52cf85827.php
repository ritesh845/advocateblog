<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="card-title">Add Post
         <a href="<?php echo e(route('post.index')); ?>" class="btn btn-sm btn-primary pull-right">Back</a>
         </h5>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('post.store')); ?>" method="post" enctype="multipart/form-data" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php if (app('laratrust')->hasRole('admin|super_admin')) : ?>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label for="user_id">Select User</label>
                        <select name="user_id" class="form-control" required="required" id="user_id">
                            <option value="">Select User</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" data-id="<?php echo e($user->role_id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                         <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                            <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                
                    <div class="col-md-6 form-group d-none" id="catg_type_admin">
                        <label for="category">Catgory</label>
                         <select name="catg_id" class="form-control" id="catg_id">
                            <option value="">Select category</option>
                            <?php $__currentLoopData = collect($categories)->where('catg_type',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categorie->catg_id); ?>"><?php echo e($categorie->catg_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php $__errorArgs = ['catg_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block" role="alert">
                                <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </select>
                    </div>
                    <div class="col-md-6 form-group d-none" id="catg_type_user">
                        <label for="category">Catgory</label>
                          <select name="catg_id" class="form-control"  id="catg_id">
                            <option value="">Select category</option>
                            <?php $__currentLoopData = collect($categories)->where('catg_type',2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categorie->catg_id); ?>"><?php echo e($categorie->catg_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                         <?php $__errorArgs = ['catg_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                            <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>        
            <?php endif; // app('laratrust')->hasRole ?>

            <?php if (app('laratrust')->hasRole('user')) : ?>
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                 <div class="row">
                    <div class="col-md-6 form-group">
                        <label for="category">Catgory</label>
                        <select name="catg_id" class="form-control"  id="catg_id">
                            <option value="">Select category</option>
                            <?php $__currentLoopData = collect($categories)->where('catg_type',2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categorie->catg_id); ?>"><?php echo e($categorie->catg_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['catg_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block" role="alert">
                            <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            <?php endif; // app('laratrust')->hasRole ?>


            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" class="form-control" placeholder="Post Title" value="<?php echo e(old('title')); ?>" id="title">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 form-group">
                    <label for="sefriendly">Sefriendly Url</label>
                    <input type="text" name="sefriendly" value="<?php echo e(old('sefriendly')); ?>" class="form-control" readonly="readonly" id="sefriendly" placeholder="Sefriendly Url">
                    <?php $__errorArgs = ['sefriendly'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="start_date">Start Date</label>
                    <input type="text" name="start_date" class="form-control datepicker" placeholder="yyyy-mm-dd" data-date-format='yyyy-mm-dd' value="<?php echo e(old('start_date') ?? date('Y-m-d')); ?>" id="start_date">
                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                
            </div>
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="image">Image</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 form-group">
                    <label for="attachment">Attachment <span class="text-muted">(PDF Accepted)</span></label>
                    <input type="file" name="attachment" class="form-control" accept="application/pdf">
                    <?php $__errorArgs = ['attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>     
            <hr>                   
           
          
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="status">Status</label>
                    <select class="form-control" name="status">
                        <option value="1">Active</option>
                        <option value="0">Not Active</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="status">Meta title</label>
                    <input type="text" name="meta_title" class="form-control" placeholder="Post meta title" value="<?php echo e(old('meta_title')); ?>" id="meta_title">
                    <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 form-group">
                    <label for="status">Meta description</label>
                    
                     <input type="text" name="meta_description" class="form-control" placeholder="Post Meta Description" value="<?php echo e(old('meta_description')); ?>" id="meta_description">
                    <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 form-group">
                    <label for="status">Meta Keywords</label>
                   
                    <input type="text" name="meta_keywords" class="form-control" placeholder="Post meta keywords" value="<?php echo e(old('meta_keywords')); ?>" id="meta_keywords">
                    <?php $__errorArgs = ['meta_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>



            <div class="row">
                <div class="col-md-12 form-group">
                    <label for="body">Body</label>
                    <textarea class="form-control" name="body" rows="10" cols="20" placeholder="Enter Body Content" id="editor"><?php echo e(old('body')); ?></textarea>
                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 form-group">
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
<script >
    $(document).ready(function(){
        CKEDITOR.replace('editor');
        $('.datepicker').datepicker({
            'setDate': new Date()
        });


        $('#title').blur(function(e){
            var text = document.getElementById("title").value;
            str = text.replace(/[`~!@#$%^&*()_\-+=\[\]{};:'"\\|\/,.<>?\s]/g, ' ').toLowerCase();
            str = str.replace(/^\s+|\s+$/gm,'');
            str = str.replace(/\s+/g, '-')+'.html';   
            $("#sefriendly").val(str); 
        });

        $('#user_id').on('change',function(e){
            e.preventDefault();
            var role_id = $(this).find(':selected').data('id');
            if(role_id == 3){
                $('#catg_type_user').removeClass('d-none');
                $('#catg_type_admin').addClass('d-none');
            }else{
                $('#catg_type_user').addClass('d-none');
                $('#catg_type_admin').removeClass('d-none');

            }

        })


    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/posts/create.blade.php ENDPATH**/ ?>