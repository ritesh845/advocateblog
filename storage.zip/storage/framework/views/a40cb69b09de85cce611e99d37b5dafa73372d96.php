                  
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('backend/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/echart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/chat-init.js')); ?>"></script>
    <!-- chat messages initilization  -->
    <script src="<?php echo e(asset('backend/js/custom.js')); ?>"></script>
    <!-- scripts -->
    <script src="<?php echo e(asset('backend/js/peity-circle.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/custom2.js')); ?>"></script>
</body>


<!-- Mirrored from wpkixx.com/html/wooble/index4.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Mar 2021 11:04:48 GMT -->
</html><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/template/partials/footer.blade.php ENDPATH**/ ?>