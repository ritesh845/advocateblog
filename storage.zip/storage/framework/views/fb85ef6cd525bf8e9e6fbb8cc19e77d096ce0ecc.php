<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 py-100">
                <div class="border rounded bg-white">
                    <img class="img-fluid w-100 rounded-top" src="<?php echo e(asset('storage/'.$post->image_path)); ?>" alt="<?php echo e($post->title); ?>">
                    <div class="p-4">
                        <h3><?php echo e($post->title); ?></h3>
                        <ul class="list-inline d-block pb-4 border-bottom mb-3">
                            <li class="list-inline-item text-color">Posted By Admin</li>
                            <li class="list-inline-item text-color">On <?php echo e(date('d M Y',strtotime($post->start_date))); ?></li>
                            <li class="list-inline-item text-color">in <?php echo e($post->category->catg_name); ?></li>
                        </ul>
                        <?php echo $post->body; ?>

                    </div>
                </div>
                
            </div>
            <div class="col-lg-4">
                <!-- Sidebar -->
                <div class="bg-white px-4 py-100 sidebar-box-shadow">
                    <!-- Search Widget -->
                    
                    <!-- categories -->
                    <div class="mb-50">
                        <h4 class="mb-3">Categories</h4>
                        <ul class="pl-0 mb-0">
                            <li class="border-bottom">
                                <a href="#" class="d-block text-color py-10">Business Analysis</a>
                            </li>
                           
                        </ul>
                    </div>
                    <!-- Widget Recent Post -->
                    <div class="mb-50">
                        <h4 class="mb-3">Recent News</h4>
                        <div class="d-flex py-3 border-bottom">
                            <div class="mr-4">
                                <a href="blog-single.html">
                                    <img class="rounded" src="images/blog/post-thumb-sm-01.jpg" alt="post-thumb">
                                </a>
                            </div>
                            <div>
                                <h6 class="mb-3">
                                    <a class="text-dark" href="blog-single.html">Marketing Strategy 2017-2018.</a>
                                </h6>
                                <p class="meta">16 Dec, 2018</p>
                            </div>
                        </div>
                       
                    </div>
                    <!-- Widget Tags -->
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/template/pages/post_detail.blade.php ENDPATH**/ ?>