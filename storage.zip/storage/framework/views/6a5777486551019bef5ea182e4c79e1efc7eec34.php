<?php $__env->startSection('content'); ?>
<div class="card mb-5">
  <div class="card-header">
      <h5 class="card-title">Posts</h5>
  </div>
  <div class="card-body">
  		<div class="row">
  			<div class="col-md-12">
  				
  			</div>
  		</div>
  		<div class="row">
  			<div class="col-md-12 table-responsive">
  				<table class="table table-bordered table-striped">
  					<thead>
  						<tr>
  							<th>#</th>
  							<th>Title</th>
  							<th>Body</th>
  							<th>Image</th>
  							<th>status</th>
  							<th>Action</th>
  						</tr>
  					</thead>
  					<tbody>
  						<?php $count = 1; ?>
  						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  						<tr>
	  							<td><?php echo e($count++); ?></td>
	  							<td><?php echo e($post->title); ?></td>
	  							<td><?php echo Str::limit($post->body,150,$end='...'); ?></td>
	  							<td></td>
	  							<td><?php echo e($post->status == '1' ? 'Active' : 'Not Active'); ?></td>
	  							<td>
	  								<a href="<?php echo e(route('post.show',$post->article_id)); ?>"><i class="fa fa-eye text-primary"></i></a>

	  								<a href="<?php echo e(route('post.edit',$post->article_id)); ?>"><i class="fa fa-edit text-success"></i></a>

	  								<a href="<?php echo e(route('post.delete',$post->article_id)); ?>" onclick="return confirm('Are you sure you want to delete this post')"><i class="fa fa-trash text-danger"></i></a>
	  							</td>
	  						</tr>
  						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  					</tbody>
  				</table>
  			</div>
  		</div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/posts/index.blade.php ENDPATH**/ ?>