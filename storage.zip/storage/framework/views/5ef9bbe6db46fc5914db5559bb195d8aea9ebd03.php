<?php $__env->startSection('content'); ?>
<div class="card mb-5">
  <div class="card-header">
      <h5 class="card-title">Profile</h5>
  </div>
  <div class="card-body">
      <div class="row">
        <div class="col-md-3">
          <img src="<?php echo e(Auth::user()->photo  == null ? asset('demo.png') : asset('storage/'.Auth::user()->photo)); ?>" width="230" height="150" class="shadow-sm">
        </div>
        <div class="col-md-9">
           <h5 class="font-weight-bold">Basic Details:</h5>

           <div class="row">
              <div class="col-md-6">
                  <p class="m-1">Name: <?php echo e($user->name); ?></p>
                  <p class="m-1">Email Address: <?php echo e($user->email); ?></p>
                  <p class="m-1">Mobile Number: <?php echo e($user->mobile); ?></p> 
                  <p class="m-1">Aadhar Card: <?php echo e($user->aadhar_card); ?></p> 
              </div>
              <div class="col-md-6">
                  <p class="m-1">Gender: <?php echo e(Arr::get(GENDER,$user->gender)); ?></p>
                  <p class="m-1">Licence Number: <?php echo e($user->licence_no); ?></p>
                  <p class="m-1">Date of Birth: <?php echo e(date('d-m-Y',strtotime($user->dob))); ?></p>
                  <p class="m-1">PAN Card: <?php echo e($user->pan_card); ?></p> 
              </div>
           </div>
           <hr>
           <h5 class="font-weight-bold">Address Details:</h5>

           <div class="row">
              <div class="col-md-6">
                  <p class="m-1">Address Line 1: <?php echo e($user->addr1); ?></p>
                  <p class="m-1">Address Line 2: <?php echo e($user->addr2); ?></p>
                  <p class="m-1">Country: <?php echo e($user->country !=null ? $user->country->country_name : ''); ?></p> 
                  <p class="m-1">State: <?php echo e($user->state !=null ? $user->state->state_name : ''); ?></p> 
              </div>
              <div class="col-md-6">
                  <p class="m-1">City: <?php echo e($user->city !=null ? $user->city->city_name : ''); ?></p>
                  <p class="m-1">Zip Code: <?php echo e($user->zip_code); ?></p>
              </div>
           </div>
           <hr>
            <h5 class="font-weight-bold">About Details:</h5>

           <div class="row">
              <div class="col-md-12">
                  <?php echo $user->detl_profile; ?>

              </div>
           </div>

        </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/profile/index.blade.php ENDPATH**/ ?>