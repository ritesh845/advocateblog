<!DOCTYPE html>
<html lang="zxx">


<!-- Mirrored from demo.themefisher.com/biztrox/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Mar 2021 09:04:06 GMT -->
<head>
  <meta charset="utf-8">
  <title><?php echo $__env->yieldContent('title','Advocate Mail'); ?></title>

  
  <!-- mobile responsive meta -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  
  <!-- Bootstrap -->
  <link rel="stylesheet" href="<?php echo e(asset('template/plugins/bootstrap/bootstrap.min.css')); ?>">
  <!-- magnific popup -->
  <link rel="stylesheet" href="<?php echo e(asset('template/plugins/magnific-popup/magnific-popup.css')); ?>">
  <!-- Slick Carousel -->
  <link rel="stylesheet" href="<?php echo e(asset('template/plugins/slick/slick.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('template/plugins/slick/slick-theme.css')); ?>">
  <!-- themify icon -->
  <link rel="stylesheet" href="<?php echo e(asset('template/plugins/themify-icons/themify-icons.css')); ?>">
  <!-- animate -->
  <link rel="stylesheet" href="<?php echo e(asset('template/plugins/animate/animate.css')); ?>">
  <!-- Aos -->
  <link rel="stylesheet" href="<?php echo e(asset('template/plugins/aos/aos.css')); ?>">
  <!-- swiper -->
  <link rel="stylesheet" href="<?php echo e(asset('template/plugins/swiper/swiper.min.css')); ?>">
  <!-- Stylesheets -->
  <link href="<?php echo e(asset('template/css/template.css')); ?>" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  

</head>

<body>
  

<!-- preloader start -->
<div class="preloader">
    <img src="<?php echo e(asset('template/img/preloader.gif')); ?>" alt="preloader">
</div>
<!-- preloader end -->

<!-- navigation -->
<header>
    <!-- top header -->
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-inline text-lg-right text-center">
                        <li class="list-inline-item">
                            <a href="">Email Login</a>
                        </li>
                       <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="list-inline-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>
                            
                            <?php if(Route::has('register')): ?>
                                <li class="list-inline-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>

                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- nav bar -->
    <div class="navigation">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand " href="<?php echo e(url('/')); ?>">
                   
                    <img src="<?php echo e(asset('template/img/'.session('site_logo'))); ?>" alt="logo">
                    
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">

                        <?php $__currentLoopData = session('catgs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e($catg->catg_url !=null ? url($catg->catg_url) : '#'); ?>"><?php echo e($catg->catg_name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if(auth()->guard()->guest()): ?>
                           
                        <?php else: ?>
                            <li class="nav-item dropdown active">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?>

                                </a>
                                <div class="dropdown-menu" >
                                    <a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                                     <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    
                                </div>
                            </li>

                        <?php endif; ?>

                        
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</header><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/template/partials/header.blade.php ENDPATH**/ ?>