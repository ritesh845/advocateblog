<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">
      <h4 class="card-title">Edit profile</h4>
  </div>
  <div class="card-body">
      <form action="<?php echo e(route('profile.update',$user->id)); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <div class="row">
            <div class="col-md-12">
                  <h5>Basic Details:</h5>
                 <hr/>
             </div>
             <div class="col-md-4 form-group col-sm-4 field">
                <label>Your Full Name <span>*</span> </label>
                <input value="<?php echo e(old('name') ?? $user->name); ?>" type="text" name="name" class="form-control">
                 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
             </div>
             <div class="col-md-4 form-group col-sm-4 field">
             <label>Email Address <span>*</span> </label>
                 <input value="<?php echo e($user->email); ?>" readonly="readonly" type="email" name="email" class="form-control">
                 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
             </div>
             <div class="col-md-4 form-group col-sm-4 field">
             <label>Mobile Number <span>*</span> </label>
                 <input  type="text" name="mobile" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" value="<?php echo e(old('mobile') ?? $user->mobile); ?>" class="form-control">
                 <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
             </div>
             <div class="col-md-4 form-group col-sm-4 field">
             <label>Licence Number <span>*</span> </label>
                 <input value="<?php echo e(old('licence_no') ?? $user->licence_no); ?>" type="text" name="licence_no" class="form-control">
                 <?php $__errorArgs = ['licence_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
             </div>
             <div class="col-md-4 form-group col-sm-4 field">
                 <label>Gender <span>*</span> </label>
                 <select  class="form-control" name="gender">
                     <option value="">Select Gender</option>
                    <?php $__currentLoopData = GENDER; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($key); ?>" <?php echo e((old('gender') ?? $user->gender) == $key ? 'selected' : ''); ?>><?php echo e($gender); ?></option>
                     
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 

             </div>
             <div class="col-md-4 form-group col-sm-4 field">
                <label>Date Of Birth <span>*</span></label>
                <input value="<?php echo e(old('dob') ?? date('Y-m-d',strtotime($user->dob))); ?>" placeholder="YYYY-MM-DD" data-date-format="yyyy-mm-dd" type="text" class="datepicker form-control" name="dob">
                <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
             </div> 
             <div class="col-md-4 form-group col-sm-4 field">
                <label>Aadhar Card <span>*</span> </label>
                <input value="<?php echo e(old('aadhar_card') ?? $user->aadhar_card); ?>" type="text" name="aadhar_card" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" value="<?php echo e(old('aadhar_card')); ?>" class="form-control"> 
                <?php $__errorArgs = ['aadhar_card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
             </div>
             <div class="col-md-4 form-group col-sm-4 field">
                <label>Pan Card <span>*</span> </label>
                <input value="<?php echo e(old('pan_card') ?? $user->pan_card); ?>" type="text" name="pan_card" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" value="<?php echo e(old('pan_card')); ?>" class="form-control">
                <?php $__errorArgs = ['pan_card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
             </div>

             <div class="col-md-4 form-group col-sm-4 field">
                <label>Photo <span>*</span> </label>
                <input  type="file" name="photo" class="form-control">
                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 

             </div>
        </div>
        <div class="row">
             <div class="col-md-12">
                  <h5>Address Details:</h5>
                 <hr/>
             </div>
        </div>
        <div class="row">
           <div class="col-md-4 form-group col-sm-4 field">
              <label>Address Line 1  <span>*</span></label>
              <input value="<?php echo e(old('addr1') ?? $user->addr1); ?>" placeholder="Enter Address Line 1" name="addr1" type="text" class="form-control"> 
              <?php $__errorArgs = ['addr1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="text-danger" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
           </div>
           <div class="col-md-4 form-group col-sm-4 field">
              <label>Address Line 2 </label>
              <input value="<?php echo e(old('addr2') ?? $user->addr2); ?>" placeholder="Enter Address Line 2" name="addr2"  type="text" class="form-control"> 
              <?php $__errorArgs = ['aadr2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="text-danger" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
           </div>
        </div>
        <div class="row">
         <div class="col-md-4 form-group col-sm-4 field">
           <label>Country <span>*</span> </label>
            <select class="form-control" name="country_code">
              <option value="102">India</option>
            </select>
            <?php $__errorArgs = ['country_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
         </div>
           <div class="col-md-4 form-group col-sm-4 field">
           <label>State <span>*</span> </label>
            <select class="form-control" id="state" name="state_code">
                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($state->state_code); ?>" <?php echo e((old('city_code') ?? $user->state_code) === $state->state_code ? 'selected' : ''); ?>><?php echo e($state->state_name); ?></option>
                 
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php $__errorArgs = ['state_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <span class="text-danger" role="alert">
                       <strong><?php echo e($message); ?></strong>
                   </span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </select>
         </div>
           <div class="col-md-4 form-group col-sm-4 field">
           <label>City <span>*</span> </label>
            <select class="form-control" id="city" name="city_code">
              
            </select>
            <?php $__errorArgs = ['city_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         </div>
         <div class="col-md-4 form-group col-sm-4 field">
            <label>Zip Code <span>*</span></label>
            <input name="zip_code" placeholder="Enter Zip Code" type="text" class="form-control" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" value="<?php echo e(old('zip_code') ?? $user->zip_code); ?>" >
            <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         </div>
        </div>
        <div class="row">
         <div class="col-md-12">
             <h5>About Details:</h5>
             <hr/>
         </div>
        </div>
        <div class="row">
          <div class="col-md-12 form-group">
             <textarea name="detl_profile" class="form-control" rows="6" cols="6"><?php echo e(old('detl_profile') ?? $user->detl_profile); ?></textarea>
             <?php $__errorArgs = ['detl_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
             <button class="btn btn-sm btn-success mt-0">Submit</button>
          </div>
        </div>
      </form>
  </div>
</div>

<script>
   <?php if($message = Session('success')): ?>
         alert("<?php echo e($message); ?>");
   <?php endif; ?>

   $(document).ready(function(){
     $('.datepicker').datepicker();
      $('#state').on('change',function(e){
            e.preventDefault();
            var state_code = $(this).val();
            fn_state_code(state_code);
        });
        var stateCode = "<?php echo e(old('state_code') ?? $user->state_code); ?>";
        var cityCode = "<?php echo e(old('city_code') ?? $user->city_code); ?>";
        if(stateCode !=''){
            fn_state_code(stateCode,cityCode)
        }

   })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/profile/edit.blade.php ENDPATH**/ ?>