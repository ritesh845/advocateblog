    
        
            </div>
        </div>
            <!-- End of Main Content -->

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    

    <script src="<?php echo e(asset('backend/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('backend/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('backend/js/sb-admin-2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/helper.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>
        <script src="<?php echo e(asset("ckeditor/ckeditor.js")); ?>"></script>
        

    <script>
        $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });
    </script>
    <!-- Page level plugins -->
    

    <!-- Page level custom scripts -->
    
    

</body>

</html><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/partials/footer.blade.php ENDPATH**/ ?>