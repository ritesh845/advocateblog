<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Welcome to the IAP JOBS PORTAL <?php echo e($user['name']); ?> </h2>

<br/>
<h3>Your registered email-id is <?php echo e($user['email']); ?> , Please click on the below link to verify your email account</h3>
<br/>
<div style="width: 100%; height: 200px; text-align: center">
<a href="<?php echo e(url('/verify/'. $user['remember_token'])); ?>" style="border:1px solid #3490dc; background-color: #3490dc; color:white; padding: 5px; font-size: 16px; text-decoration: none">Verify Email</a>
</div>
</body>

</html><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/mail/verify_mail.blade.php ENDPATH**/ ?>