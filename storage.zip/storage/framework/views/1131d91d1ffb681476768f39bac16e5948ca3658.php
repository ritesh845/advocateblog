<li class="nav-item active">
    <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
</li>

<?php if (app('laratrust')->hasRole('super_admin')) : ?>
    <li class="nav-item">
        <a href="" class="nav-link">
            <i class="fas fa-users"></i>
            <span>Users</span>
        </a>
    </li>
    <li class="nav-item">
        <a href="" class="nav-link">
            <i class="fas fa-users"></i>
            <span>Category</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseDomain"
            aria-expanded="true" aria-controls="collapseDomain">
            <i class="fas fa-fw fa-cog"></i>
            <span>Domain</span>
        </a>
        <div id="collapseDomain" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('domain.index')); ?>">Domain</a>
                <a class="collapse-item" href="<?php echo e(route('domain.assgine')); ?>">Add Domain</a>
                
            </div>
        </div>
    </li>

    
<?php endif; // app('laratrust')->hasRole ?>
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne"
        aria-expanded="true" aria-controls="collapseOne">
        <i class="fas fa-fw fa-cog"></i>
        <span>Posts</span>
    </a>
    <div id="collapseOne" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('post.index')); ?>">Post</a>
            <a class="collapse-item" href="<?php echo e(route('post.create')); ?>">Add Post</a>
            
        </div>
    </div>
</li>

<?php if (app('laratrust')->hasRole('user')) : ?>
<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
        aria-expanded="true" aria-controls="collapseTwo">
        <i class="fas fa-fw fa-cog"></i>
        <span>Profile</span>
    </a>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('profile.index')); ?>">Profile</a>
            <a class="collapse-item" href="<?php echo e(route('profile.edit')); ?>">Edit Profile</a>
            <a class="collapse-item" href="<?php echo e(route('specialization')); ?>">Specialization</a>
            <a class="collapse-item" href="<?php echo e(route('qualification')); ?>">Qualification</a>
        </div>
    </div>
</li>
<?php endif; // app('laratrust')->hasRole ?>
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
<button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

<?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/partials/sidepanel.blade.php ENDPATH**/ ?>