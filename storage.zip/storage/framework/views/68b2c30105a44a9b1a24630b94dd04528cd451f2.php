<?php echo $__env->make(session('template_name').'.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main>
	<?php echo $__env->yieldContent('content'); ?>
</main>
<?php echo $__env->make(session('template_name').'.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/ritesh/code/advocate_blog/resources/views/layouts/main.blade.php ENDPATH**/ ?>