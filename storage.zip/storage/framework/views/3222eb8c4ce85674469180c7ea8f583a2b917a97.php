<div class="footer">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="copyright">
					<p>

					Copyright ©2021 All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="" target="_blank">Liber Solution Soft Pvt LTD</a>

					</p>
				</div>
			</div>
		</div>
	</div>
</div>

</div>


<script src="<?php echo e(asset('template/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/jquery.stellar.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/template_one.js')); ?>"></script>

</body>
</html><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/template_one/partials/footer.blade.php ENDPATH**/ ?>