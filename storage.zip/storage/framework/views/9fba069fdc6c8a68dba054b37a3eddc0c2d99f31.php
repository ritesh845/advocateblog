<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="card card-primary">
			<div class="card-body">
				<form action="<?php echo e(route('qualification.store')); ?>" method="post" autocomplete="off">
				<?php echo e(csrf_field()); ?>

				<div class="row form-group" >
					<div class="col-md-6"  style="margin-top:10px;" >
						<label>Course Type <span class="text-danger">*</span></label>
						<select class="form-control" name="qual_catg_code" id="qual_catg_code" required="required"> 
							<option value="0">Select course type</option>
							<?php $__currentLoopData = $qual_catgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qual_catg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($qual_catg->qual_catg_code); ?>" <?php echo e(old('qual_catg_code') == $qual_catg->qual_catg_code  ? 'selected' :  ''); ?> > <?php echo e($qual_catg->qual_catg_desc); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>

						<?php $__errorArgs = ['qual_catg_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback text-danger" role="alert">
							<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="col-md-6" style="margin-top:10px;"> 
						<label for="qual_code">Course Name <span class="text-danger">*</span></label>
						<select class="form-control" name="qual_code" id="qual_sub" required="required">
						</select>
						<?php $__errorArgs = ['qual_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback text-danger" role="alert">
							<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-md-6" style="margin-top:10px;"> 
						<label>Passing Year <span class="text-danger">*</span></label>
						<input type="text" name="pass_year" placeholder="Enter passing year" class="form-control" value="<?php echo e(old('pass_year')); ?>" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" required="required">
						<?php $__errorArgs = ['pass_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback text-danger" role="alert">
							<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="col-md-6" style="margin-top:10px;"> 
						<label for="pass_perc">Passing Percentage <span class="text-danger">*</span></label>
						<input type="text" name="pass_perc" placeholder="Enter passing Percentage" class="form-control" value="<?php echo e(old('pass_perc')); ?>" oninput="this.value = this.value.replace(/[^0-9|.]/g, '').replace(/(\..*)\./g, '$1');" required="required">
						<?php $__errorArgs = ['pass_perc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback text-danger" role="alert">
							<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
						
				</div>
				<div class="row form-group">
					<div class="col-md-6" style="margin-top:10px;">
						<label for="pass_division">Passing Division <span class="text-danger">*</span></label>
						<select name="pass_division" class="form-control" required="required">
							<option value="0">Select Division</option>
							<option value="1" <?php echo e(old('pass_division')=='1' ? 'selected' : ''); ?>>1st</option>
							<option value="2" <?php echo e(old('pass_division')=='2' ? 'selected' : ''); ?>>2nd</option>
							<option value="3" <?php echo e(old('pass_division')=='3' ? 'selected' : ''); ?>>3rd</option>
						</select>
						<?php $__errorArgs = ['pass_division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback text-danger" role="alert">
							<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12" style="margin-top:10px;">
						<button class="btn btn-md btn-primary" class="form-control" id="submit1">Submit</button>
					</div>
				</div>
			</form>
			</div>
		</div>
	</div>
			
	<div class="col-md-12 ">
		<div class="card card-primary">
			<div class="card-header with-border" >
				<h3 style="margin-top: 10px;">Your Qualification</h3>
			</div>
		<div class="card-body table-responsive ">
			<table id="qualification" class="table table-hover table-striped">
					<thead>
						<tr>
							<th>S.No.</th>
							<th>Course Type</th>
							<th>Course Name</th>
							<th>Passing Year</th>
							<th>Passing Percentage</th>
							<th>Passing Division</th>
						</tr>							
					</thead>
					<tbody>
						<?php $count = 0; ?>
						<?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quali): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e(++$count); ?></td>
							<td><?php echo e($quali->qual_catg_desc); ?></td>
							<td><?php echo e($quali->qual_desc); ?></td>
							<td><?php echo e($quali->pass_year); ?></td>
							<td><?php echo e($quali->pass_perc); ?></td>
							<td><?php echo e($quali->pass_division); ?></td>	
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				
			</div>
		</div>
	</div>
</div>

<?php if($message = Session::get('warning')): ?>
	<script type="text/javascript">
		var messsge = "<?php echo e($message); ?>";
		alert(messsge);
	</script>
<?php endif; ?>
<?php if($message = Session::get('success')): ?>
	<script type="text/javascript">
		var messsge = "<?php echo e($message); ?>";
		alert(messsge);
	</script>
<?php endif; ?>

<script type="text/javascript">

	$(document).ready(function(){
		// $('#qualification').DataTable();
	});

$(document).ready(function(){
	$('#qual_catg_code').on('change',function(){
		var qual_catg_code = $(this).val();

		fn_get_qual(qual_catg_code);
	});
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/profile/qualification.blade.php ENDPATH**/ ?>