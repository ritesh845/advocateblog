<div class="container">
	<div class="row">
		<div class="col-lg-9">
			<div class="section-title">
				<span class="caption d-block small">Categories</span>
				<h2>About</h2>
			</div>
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="post-entry-2 d-flex">
					<div class="thumbnail order-md-2" style="background-image: url('<?php echo e(asset('storage/'.$post->image_path)); ?>')"></div>
					<div class="contents order-md-1 pl-0">
						<h2><a href="blog-single.html"><?php echo e($post->title); ?></a></h2>
						<p class="mb-3"><?php echo Str::limit($post->body,120,$end='...'); ?></p>
						<div class="post-meta">
							<span class="d-block"><a href="#">By <?php echo e($post->user->name); ?></a> in <a href="#"><?php echo e($post->category->catg_name); ?></a></span>
							<span class="date-read"><?php echo e(date('M d Y ', strtotime($post->start_date))); ?> </span>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>
		<?php echo $__env->make('template_one.pages.sidepanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/template_one/pages/about.blade.php ENDPATH**/ ?>