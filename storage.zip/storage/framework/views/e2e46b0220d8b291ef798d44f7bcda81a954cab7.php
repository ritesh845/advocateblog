
<?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/domain/index.blade.php ENDPATH**/ ?>