<?php echo $__env->make('backend.template.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <div class="main-content">

<!-- responsive header -->
<div class="panel-body">
    <div class="content-area">
        <div class="sub-bar">
            <div class="sub-title">
                <h4>Dashboard:</h4>
                <span>Welcome To web Admin Panel!</span>
            </div>
            <ul class="bread-crumb">
                <li><a href="#" title="">Home</a></li>
                <li>Dashbord</li>
            </ul>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-12">
                <div class="top-widget">
                    
                    <div class="informative">
                        <span>100</span>
                        <em>total posts</em>
                    </div>
                </div>
            </div>
           
        </div>

    </div>
    <div class="bottombar"> 
        <span>© 2019. All Rights Reserved.</span>
    </div>
    <!-- bottombar -->
</div>
</div>
<?php echo $__env->make('backend.template.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/template/layouts/main.blade.php ENDPATH**/ ?>