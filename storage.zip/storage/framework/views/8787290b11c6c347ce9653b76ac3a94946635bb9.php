<div class="footer-bar">
	<div class="outer-container">
		<div class="container-fluid">
			<div class="row justify-content-between">
				<div class="col-12 col-md-6">
					<div class="footer-copyright">

					<p>Copyright ©<script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script>document.write(new Date().getFullYear());</script>2021 All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com/" target="_blank">Colorlib</a></p>

					</div>
				</div>
				<div class="col-12 col-md-6">
					<div class="footer-social">
						<ul class="flex justify-content-center justify-content-md-end align-items-center">
							<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
							<li><a href="#"><i class="fa fa-behance"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

<script type='text/javascript' src='<?php echo e(asset('template/js/swiper.min.js')); ?>'></script>
<script type='text/javascript' src='<?php echo e(asset('template/js/template_two.js')); ?>'></script>
</body>
</html><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/template_two/partials/footer.blade.php ENDPATH**/ ?>