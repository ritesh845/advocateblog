<div class="sub-bar">
    <div class="sub-title">
        <h4><?php echo e($name); ?>:</h4>
        <span>Welcome To web Admin Panel!</span>
    </div>            
</div><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/backend/layouts/sub_bar.blade.php ENDPATH**/ ?>