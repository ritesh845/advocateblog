<?php $__env->startSection('content'); ?>
<?php if(\View::exists(session('template_name').'.pages.directory')): ?>
	<?php echo $__env->make(session('template_name').'.pages.directory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
 <?php 
 abort(404); 
 ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ritesh/code/advocate_blog/resources/views/pages/directory.blade.php ENDPATH**/ ?>